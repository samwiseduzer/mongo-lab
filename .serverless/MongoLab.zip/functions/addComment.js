(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 19);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("node-lambda-toolkit");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("mongoose");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/regenerator");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/promise");

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = __webpack_require__(1);

var _mongoose2 = _interopRequireDefault(_mongoose);

var _mongooseUniqueValidator = __webpack_require__(11);

var _mongooseUniqueValidator2 = _interopRequireDefault(_mongooseUniqueValidator);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var CommentSchema = new _mongoose.Schema({
  user: {
    type: String,
    required: [true, "User is required"],
    unique: false,
    select: true
  },
  text: {
    type: String,
    required: [true, "Text is required"],
    unique: false,
    select: true
  }
}, { timestamps: true });

CommentSchema.plugin(_mongooseUniqueValidator2.default);

var Comment = _mongoose2.default.models.Comment || _mongoose2.default.model("Comment", CommentSchema);

exports.default = Comment;

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/toConsumableArray");

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("source-map-support/register");

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});

var _stringify = __webpack_require__(9);

var _stringify2 = _interopRequireDefault(_stringify);

var _promise = __webpack_require__(4);

var _promise2 = _interopRequireDefault(_promise);

var _mongoose = __webpack_require__(1);

var _mongoose2 = _interopRequireDefault(_mongoose);

var _nodeLambdaToolkit = __webpack_require__(0);

var _models = __webpack_require__(10);

var _models2 = _interopRequireDefault(_models);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// use built-in promises
_mongoose2.default.Promise = global.Promise;

exports.default = function (context) {
	context.callbackWaitsForEmptyEventLoop = false;

	return new _promise2.default(function (resolve, reject) {
		console.log('Connecting to DB: ', process.env.NODE_ENV);
		try {
			if (![1, 2].includes(_mongoose2.default.connection.readyState)) {
				console.log('connecting to db...');
				_mongoose2.default.connect(process.env.MONGO_DB_CONN_STR, { autoIndex: !!process.env.ADDING_INDICES }, function (err) {
					if (err) {
						console.log('Failed to connect:', err);
						reject(new MongoConnectError(err));
					}
				});
			} else {
				console.log('reusing old db connection...');
				resolve('connected');
			}
		} catch (err) {
			console.log('Failed to connect:', err);
			reject(new MongoConnectError(err));
		}

		_mongoose2.default.connection.once('open', function () {
			// mongoose.set('debug', true);
			console.log('connected to DB');
			_mongoose2.default.connection.on('error', function (err) {
				console.log('Mongoose Error:');
				console.log((0, _stringify2.default)(err));
			});
			_mongoose2.default.connection.on('disconnected', function () {
				console.log('-> lost connection');
			});
			_mongoose2.default.connection.on('index', function (err) {
				if (err) console.log('ERROR CREATING INDEXES:', err);else console.log('Successfully created indexes');
			});
			resolve('connected');
		});
	});
};

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Comment = undefined;

var _comment = __webpack_require__(5);

var _comment2 = _interopRequireDefault(_comment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.Comment = _comment2.default;
exports.default = {
  Comment: _comment2.default
};

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("mongoose-unique-validator");

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.listComments = exports.deleteComments = exports.addComment = undefined;

var _toConsumableArray2 = __webpack_require__(6);

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _regenerator = __webpack_require__(2);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _assign = __webpack_require__(13);

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = __webpack_require__(3);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _promise = __webpack_require__(4);

var _promise2 = _interopRequireDefault(_promise);

var _nodeLambdaToolkit = __webpack_require__(0);

var _comment = __webpack_require__(5);

var _comment2 = _interopRequireDefault(_comment);

var _mongo = __webpack_require__(14);

var _mongoose = __webpack_require__(1);

var _mongoose2 = _interopRequireDefault(_mongoose);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var addComment = exports.addComment = function addComment(payload) {
  return new _promise2.default(function () {
    var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(resolve, reject) {
      var newComment, validation, savedComment;
      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              newComment = new _comment2.default((0, _assign2.default)({}, payload));
              validation = (0, _mongo.validate)(newComment);

              if (validation.isValid) {
                _context.next = 7;
                break;
              }

              reject(new _nodeLambdaToolkit.ValidationError(validation.errors));
              _context.next = 11;
              break;

            case 7:
              _context.next = 9;
              return newComment.save({ new: true });

            case 9:
              savedComment = _context.sent;

              resolve(savedComment);

            case 11:
              _context.next = 16;
              break;

            case 13:
              _context.prev = 13;
              _context.t0 = _context["catch"](0);

              reject((0, _nodeLambdaToolkit.proliferateThrownError)(_context.t0, "Failed to create new Comment"));

            case 16:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, undefined, [[0, 13]]);
    }));

    return function (_x, _x2) {
      return _ref.apply(this, arguments);
    };
  }());
};

var deleteComments = exports.deleteComments = function deleteComments() {
  return new _promise2.default(function () {
    var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(resolve, reject) {
      var results;
      return _regenerator2.default.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _context2.next = 3;
              return _mongoose2.default.connection.dropCollection("comments");

            case 3:
              results = _context2.sent;

              resolve({ message: "success", results: results });
              _context2.next = 10;
              break;

            case 7:
              _context2.prev = 7;
              _context2.t0 = _context2["catch"](0);

              reject((0, _nodeLambdaToolkit.proliferateThrownError)(_context2.t0, "Failed to remove comment"));

            case 10:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, undefined, [[0, 7]]);
    }));

    return function (_x3, _x4) {
      return _ref2.apply(this, arguments);
    };
  }());
};

var listComments = exports.listComments = function listComments() {
  var criteria = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  var _ref3 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {
    orderBy: "createdAt",
    populate: [],
    select: ["_id"]
  },
      _ref3$orderBy = _ref3.orderBy,
      orderBy = _ref3$orderBy === undefined ? "createdAt" : _ref3$orderBy,
      _ref3$populate = _ref3.populate,
      populate = _ref3$populate === undefined ? [] : _ref3$populate,
      _ref3$select = _ref3.select,
      select = _ref3$select === undefined ? ["_id"] : _ref3$select;

  return new _promise2.default(function () {
    var _ref4 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(resolve, reject) {
      var _Comment$find$sort, comments;

      return _regenerator2.default.wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.prev = 0;
              _context3.next = 3;
              return (_Comment$find$sort = _comment2.default.find(criteria).sort(orderBy)).populate.apply(_Comment$find$sort, (0, _toConsumableArray3.default)(populate)).exec();

            case 3:
              comments = _context3.sent;

              resolve(comments || []);
              _context3.next = 10;
              break;

            case 7:
              _context3.prev = 7;
              _context3.t0 = _context3["catch"](0);

              reject((0, _nodeLambdaToolkit.proliferateThrownError)(_context3.t0, "Failed to get comments"));

            case 10:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3, undefined, [[0, 7]]);
    }));

    return function (_x7, _x8) {
      return _ref4.apply(this, arguments);
    };
  }());
};

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/object/assign");

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getIndices = exports.tryReportValidationErr = exports.mungeValidationErr = exports.toObjectId = exports.validate = undefined;

var _toConsumableArray2 = __webpack_require__(6);

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _keys = __webpack_require__(15);

var _keys2 = _interopRequireDefault(_keys);

var _values2 = __webpack_require__(16);

var _values3 = _interopRequireDefault(_values2);

var _mapValues2 = __webpack_require__(17);

var _mapValues3 = _interopRequireDefault(_mapValues2);

var _mongoose = __webpack_require__(1);

var _mongoose2 = _interopRequireDefault(_mongoose);

var _nodeLambdaToolkit = __webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mungeValidationErr = function mungeValidationErr(error) {
	return {
		errors: (0, _mapValues3.default)(error.errors, function (e) {
			return e.message;
		}),
		message: (0, _values3.default)((0, _mapValues3.default)(error.errors, function (e) {
			return e.message;
		}))
	};
};

// run pre-save validation of model instance
var validate = function validate(instance) {
	var error = instance.validateSync();
	if (error) {
		return {
			isValid: false,
			errors: mungeValidationErr(error)
		};
	} else {
		return { isValid: true };
	}
};

var toObjectId = function toObjectId(id) {
	return _mongoose2.default.Types.ObjectId(id);
};

var tryReportValidationErr = function tryReportValidationErr(err) {
	if (err.errors) {
		return getMungedErrors(err);
	} else {
		return null;
	}
};

// get all indices in nested path to desired resource
// throw error if invalid id is part of path
var getIndices = function getIndices(obj, path) {
	var pathArr = path.split('.');
	var currResource = obj;
	var indices = {};
	pathArr.forEach(function (p) {
		var prop = p.split('/')[0];
		var id = p.split('/')[1];
		var idx = currResource[prop].findIndex(function (el) {
			return el._id && el._id.equals(id);
		});
		if (idx === -1) {
			throw new _nodeLambdaToolkit.InvalidResourceError(prop + '[' + id + '] does not exist');
		} else {
			currResource = currResource[prop][idx];
			indices[prop] = idx;
		}
	});
	return indices;
};

exports.validate = validate;
exports.toObjectId = toObjectId;
exports.mungeValidationErr = mungeValidationErr;
exports.tryReportValidationErr = tryReportValidationErr;
exports.getIndices = getIndices;


var getMungedErrors = function getMungedErrors(err) {
	var errObj = { errors: getErrors(err) };
	return mungeValidationErr(errObj);
};

var getErrors = function getErrors(err) {
	if ('errors' in err) {
		return (0, _keys2.default)(err.errors).reduce(function (all, path) {
			var newErrors = getErrors(err.errors[path]);
			return newErrors.length ? [].concat((0, _toConsumableArray3.default)(all), (0, _toConsumableArray3.default)(newErrors)) : [].concat((0, _toConsumableArray3.default)(all), [newErrors]);
		}, []);
	} else {
		return { message: err.message };
	}
};

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/object/keys");

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = require("lodash/values");

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("lodash/mapValues");

/***/ }),
/* 18 */,
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _regenerator = __webpack_require__(2);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(3);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

__webpack_require__(7);

var _nodeLambdaToolkit = __webpack_require__(0);

var _connectToDB = __webpack_require__(8);

var _connectToDB2 = _interopRequireDefault(_connectToDB);

var _comment = __webpack_require__(12);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var bootstrap = (0, _nodeLambdaToolkit.scaffold)({
  errMsg: "ERROR ADDING COMMENT:",
  connectToDB: _connectToDB2.default
});

module.exports.handler = function () {
  for (var _len = arguments.length, input = Array(_len), _key = 0; _key < _len; _key++) {
    input[_key] = arguments[_key];
  }

  bootstrap(input, function () {
    var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req) {
      var comment;
      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return (0, _comment.addComment)(req.body);

            case 2:
              comment = _context.sent;
              return _context.abrupt("return", comment);

            case 4:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, undefined);
    }));

    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }());
};

/***/ })
/******/ ])));
//# sourceMappingURL=addComment.js.map